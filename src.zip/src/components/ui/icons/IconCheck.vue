<template>
    <svg width="11" height="9" viewBox="0 0 11 9" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path id="Vector" d="M3.52083 8.125L0 4.58333L1.04167 3.54167L3.52083 6L9.54167 0L10.5833 1.0625L3.52083 8.125Z"/>
    </svg>
</template>