<template>
  <RouterLink to="/" class="flex items-center">
    <Logo />
  </RouterLink>
</template>

<script setup>
import {RouterLink} from 'vue-router'
import Logo from "@/components/ui/icons/Logo.vue"
</script>

<style scoped>

</style>