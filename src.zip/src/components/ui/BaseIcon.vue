<template>
    <i class="fa" :class="name"></i>
</template>

<script setup>
 defineProps({
   name: String
 })
</script>

