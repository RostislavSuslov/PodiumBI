<template>
    <h1>WalmartRetailDataView</h1>
</template>
<script setup>
</script>