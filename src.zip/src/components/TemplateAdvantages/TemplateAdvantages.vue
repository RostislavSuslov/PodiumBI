<template>
  <section>
    <h2>Advantages</h2>
  </section>
</template>

<script>
</script>

<style scoped>

</style>