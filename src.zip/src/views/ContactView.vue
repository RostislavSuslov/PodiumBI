<template>
  <h1>ContactView</h1>
</template>

<script setup>

</script>

<style scoped>

</style>