<template>
  <h1>PodiumBiPortalView</h1>
</template>

<script setup>

</script>

<style scoped>

</style>