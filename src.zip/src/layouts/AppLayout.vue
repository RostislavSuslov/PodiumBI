<template>
  <div class="flex flex-col min-h-[100vh]">
    
    <AppHeader/>
    <main>
      <slot/>
    </main>
    <AppFooter/>
  </div>
</template>

 