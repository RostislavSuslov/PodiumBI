<template>
    <div class="flex flex-col min-h-[100vh]">
        <AppHeader/>
        <h1>Custom layout</h1>
        <slot></slot>
       
    </div>
  </template>
  
  <script setup>

  </script>
  
  <style scoped>
  
  </style>