<template>
  <section>
    <h2>SliderReview</h2>
  </section>
</template>

<script setup>

</script>

<style scoped>

</style>