<template>
  <h1>BlogView</h1>
</template>

<script setup>

</script>

<style scoped>

</style>