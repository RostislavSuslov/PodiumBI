<template>
  <section>
    <h2>AccordionTemplate</h2>
  </section>
</template>

<script setup>

</script>

<style scoped>

</style>